package ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import modelApp.Actividad;
import modelApp.ListaActividades;
import service.Horarios;
import ui.VentanaEliminarActividad.BotonActividades;
import util.FileUtil;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.List;
import java.awt.Font;
import java.awt.CardLayout;
import javax.swing.JCheckBox;
import javax.swing.border.EtchedBorder;
import javax.swing.border.MatteBorder;

public class VentanaMatricula extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnPrincipal;
	private VentanaPrincipal vP;
	private Horarios horarios;
	private JLabel lblMatricula;
	private JLabel lblNoActividades;
	private JPanel pnActividades;
	private JLabel lblActividadNom;
	private JLabel lblIniMat;
	private JLabel lblFinMat;
	private JLabel lblFecIni;
	private JLabel lblFecFin;
	private JLabel lblBlanco;
	private JScrollPane scpnActividades;
	private JButton btnCancelar;
	private JButton btnSiguiente;
	private JLabel lblErrorMatricula;
	private BotonPulsado pBT = new BotonPulsado();
	
	/**
	 * Create the frame.
	 * @param horarios 
	 * @param vP 
	 */
	public VentanaMatricula(VentanaPrincipal vP, Horarios horarios) {
		this.vP = vP;
		this.horarios = horarios;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 933, 547);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(Color.WHITE);
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getLblMatricula());
		pnPrincipal.add(getScpnActividades());
		pnPrincipal.add(getBtnCancelar());
		pnPrincipal.add(getBtnSiguiente());
		pnPrincipal.add(getLblErrorMatricula());
	}
	private JScrollPane getScpnActividades() {
		if (scpnActividades == null) {
			scpnActividades = new JScrollPane();
			scpnActividades.setBounds(10, 58, 897, 394);
			scpnActividades.setViewportView(getPnActividades());
		}
		return scpnActividades;
	}
	private JLabel getLblMatricula() {
		if (lblMatricula == null) {
			lblMatricula = new JLabel("\u00BFA qu\u00E9 actividades desea matricularse?");
			lblMatricula.setHorizontalAlignment(SwingConstants.CENTER);
			lblMatricula.setFont(new Font("Arial", Font.BOLD, 18));
			lblMatricula.setBounds(10, 11, 897, 36);
		}
		return lblMatricula;
	}
	
	private void generarActividades() {
		List<Actividad> listaActividades = horarios.cargarActividades();
		if(listaActividades.size() == 0) {
			pnActividades = new JPanel();
			pnActividades.setLayout(new GridLayout(0, 1, 0, 0));
			pnActividades.add(getLblNoActividades());
		} else {
			for (int i = 0; i < horarios.getListaActividades().size(); i++) {
				String[] cadena = horarios.getListaActividades().get(i).toString().split(";");
				JPanel lblCbx = new JPanel();
				JCheckBox jcb = new JCheckBox();
		        jcb.setHorizontalAlignment(SwingConstants.CENTER);
		        jcb.addActionListener(pBT);
		        lblCbx.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		        lblCbx.add(jcb);
		        pnActividades.add(lblCbx);
		        for (int j = 0; j < cadena.length - 1; j++) {
		        	JLabel lbl = new JLabel(cadena[j]);
		        	lbl.setHorizontalAlignment(SwingConstants.CENTER);
		        	lbl.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		        	pnActividades.add(lbl);
				}
		    }
		}
	}
	
	class BotonPulsado implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			for (int i = horarios.getListaActividades().get(0).toString().split(";").length; i < getPnActividades().getComponentCount(); i+=horarios.getListaActividades().get(0).toString().split(";").length) {
				JPanel jpn = (JPanel) getPnActividades().getComponent(i);
				JCheckBox jcb = (JCheckBox) jpn.getComponent(0);
				if(jcb.isSelected()) {
					getLblErrorMatricula().setText(new String());
					getBtnSiguiente().setEnabled(true);
					return;
				}
			} 
			getBtnSiguiente().setEnabled(false);
			getLblErrorMatricula().setText("Debes matricularte de al menos 1 actividad");
		}
	}
	
	private JLabel getLblNoActividades() {
		if (lblNoActividades == null) {
			lblNoActividades = new JLabel();
			lblNoActividades.setHorizontalAlignment(SwingConstants.CENTER);
			lblNoActividades.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 26));
			lblNoActividades.setBounds(355, 162, 372, 38);
			lblNoActividades.setText("No hay ninguna actividad");
		}
		return lblNoActividades;
	}
	private JPanel getPnActividades() {
		if (pnActividades == null) {
			pnActividades = new JPanel();
			pnActividades.setBounds(10, 58, 897, 394);
			pnActividades.setLayout(new GridLayout(0, 6, 0, 0));
			pnActividades.add(getLblBlanco());
			pnActividades.add(getLblActividadNom());
			pnActividades.add(getLblFecIni());
			pnActividades.add(getLblFecFin());
			pnActividades.add(getLblIniMat());
			pnActividades.add(getLblFinMat());
			generarActividades();
		}
		return pnActividades;
	}
	private JLabel getLblActividadNom() {
		if (lblActividadNom == null) {
			lblActividadNom = new JLabel("Actividad");
			lblActividadNom.setHorizontalAlignment(SwingConstants.CENTER);
			lblActividadNom.setFont(new Font("Arial", Font.BOLD, 14));
			lblActividadNom.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		}
		return lblActividadNom;
	}
	private JLabel getLblIniMat() {
		if (lblIniMat == null) {
			lblIniMat = new JLabel("Inicio matriculaci\u00F3n");
			lblIniMat.setHorizontalAlignment(SwingConstants.CENTER);
			lblIniMat.setFont(new Font("Arial", Font.BOLD, 14));
			lblIniMat.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		}
		return lblIniMat;
	}
	private JLabel getLblFinMat() {
		if (lblFinMat == null) {
			lblFinMat = new JLabel("Fin matriculaci\u00F3n");
			lblFinMat.setHorizontalAlignment(SwingConstants.CENTER);
			lblFinMat.setFont(new Font("Arial", Font.BOLD, 14));
			lblFinMat.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		}
		return lblFinMat;
	}
	private JLabel getLblFecIni() {
		if (lblFecIni == null) {
			lblFecIni = new JLabel("Inicio Actividad");
			lblFecIni.setHorizontalAlignment(SwingConstants.CENTER);
			lblFecIni.setFont(new Font("Arial", Font.BOLD, 14));
			lblFecIni.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		}
		return lblFecIni;
	}
	private JLabel getLblFecFin() {
		if (lblFecFin == null) {
			lblFecFin = new JLabel("Fin Actividad");
			lblFecFin.setHorizontalAlignment(SwingConstants.CENTER);
			lblFecFin.setFont(new Font("Arial", Font.BOLD, 14));
			lblFecFin.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		}
		return lblFecFin;
	}
	private JLabel getLblBlanco() {
		if (lblBlanco == null) {
			lblBlanco = new JLabel();
			lblBlanco.setFont(new Font("Arial", Font.BOLD, 14));
			lblBlanco.setHorizontalAlignment(SwingConstants.CENTER);
			lblBlanco.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		}
		return lblBlanco;
	}
	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("Cancelar");
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCancelar.setFont(new Font("Arial", Font.BOLD, 18));
			btnCancelar.setBackground(Color.RED);
			btnCancelar.setBounds(715, 463, 192, 36);
		}
		return btnCancelar;
	}
	private JButton getBtnSiguiente() {
		if (btnSiguiente == null) {
			btnSiguiente = new JButton("Siguiente");
			btnSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarConfirmaci�n();
				}
			});
			btnSiguiente.setEnabled(false);
			btnSiguiente.setBackground(Color.GREEN);
			btnSiguiente.setFont(new Font("Arial", Font.BOLD, 18));
			btnSiguiente.setBounds(513, 463, 192, 36);
		}
		return btnSiguiente;
	}
	private void mostrarConfirmaci�n() {
		int respuesta = JOptionPane.showConfirmDialog(null, "�Est�s seguro de las actividades que has seleccionado?", "Matricula personal",  JOptionPane.INFORMATION_MESSAGE);
		if(respuesta == 0) {
			JOptionPane.showMessageDialog(null, "Su matricula se ha completado con �xito", "Matr�cula confirmada", JOptionPane.INFORMATION_MESSAGE);
			String cadena = "";
			int posicion = horarios.getListaActividades().get(0).toString().split(";").length;
			int maximo = getPnActividades().getComponentCount();
			for (int i = posicion + 1; i < maximo; i+=posicion) {
				JLabel jbl = (JLabel) getPnActividades().getComponent(i);
				JPanel jpn = (JPanel) getPnActividades().getComponent(i-1);
				JCheckBox jcb = (JCheckBox) jpn.getComponent(0);
				if(jcb.isSelected()) {
					if(maximo - posicion < i) {
						cadena += jbl.getText();
					} else {
						cadena += jbl.getText() + ";";
					} 
				}
			}
			FileUtil.saveToFileMatricula(cadena);
		}
	}
	private JLabel getLblErrorMatricula() {
		if (lblErrorMatricula == null) {
			lblErrorMatricula = new JLabel("Debes matricularte de al menos 1 actividad");
			lblErrorMatricula.setHorizontalAlignment(SwingConstants.CENTER);
			lblErrorMatricula.setForeground(Color.RED);
			lblErrorMatricula.setFont(new Font("Arial", Font.BOLD, 18));
			lblErrorMatricula.setBounds(10, 463, 493, 34);
		}
		return lblErrorMatricula;
	}
}
