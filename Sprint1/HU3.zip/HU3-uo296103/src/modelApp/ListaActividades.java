package modelApp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import util.FileUtil;

public class ListaActividades {
	private static final String FICHERO_ACTIVIDADES = "files/actividadesProgramadas.txt";
	private static final String FICHERO_INSTALACIONES = "files/instalaciones.txt";
	private List<Actividad> listaActividades = null;
	private List<String> listaInstalaciones = null;
	
	public ListaActividades() {
		listaActividades = new ArrayList<Actividad>();
		listaInstalaciones = new ArrayList<String>();
		cargarActividades();
		cargarInstalaciones();
	}

	private void cargarInstalaciones() {
		FileUtil.loadFileInstalaciones(FICHERO_INSTALACIONES, listaInstalaciones);
		
	}

	private void cargarActividades() {
		FileUtil.loadFileActividad(FICHERO_ACTIVIDADES, listaActividades);
	}
	
	public List<Actividad> getLista(){
		return listaActividades;
	}

	public List<Actividad> ordenarLista(List<Actividad> lista) {
		List<LocalDate> fechaOrdenar = new ArrayList<LocalDate>();
		for (int i = 0; i < lista.size(); i++) {
			String[] listaFecha = new String[2];
			listaFecha = lista.get(i).getFechaInicio().split("/");
			fechaOrdenar.add(LocalDate.of(Integer.parseInt(listaFecha[2]),Integer.parseInt(listaFecha[1]), Integer.parseInt(listaFecha[0])));
		}
		Collections.sort(fechaOrdenar);
		List<Actividad> nuevaLista = new ArrayList<Actividad>();
		for (int i = 0; i < lista.size(); i++) {
			String cadena = crearCadena(fechaOrdenar.get(i));
			for (int j = 0; j < lista.size(); j++) {
				if(cadena.equals(lista.get(j).getFechaInicio())) {
					nuevaLista.add(lista.get(j));
					j = lista.size();
				}
			}
		}
		return lista;
	}

	private String crearCadena(LocalDate fecha) {
		return String.valueOf(fecha.getDayOfMonth() + "/" + fecha.getMonthValue() + "/" + fecha.getYear());
	}

	public void eliminarActividad(int posicion) {
		listaActividades.remove(posicion);
		FileUtil.eliminarActividad(listaActividades);
	}

	public void reiniciarLista() {
		listaActividades = new ArrayList<Actividad>();
		cargarActividades();
		ordenarLista(listaActividades);
		
	}

	public String[] getListaInstalaciones() {
		Collections.sort(listaInstalaciones, new ComparadorMenorMayor());
		String[] instalaciones = new String[listaInstalaciones.size()];
		for (int i = 0; i < listaInstalaciones.size(); i++) {
			instalaciones[i] = listaInstalaciones.get(i);
		}
		return instalaciones;
	}
	
	class ComparadorMenorMayor implements Comparator<String> {
	    @Override
	    public int compare(String s1, String s2) {
	        return s1.compareToIgnoreCase(s2);
	    }
	}
}
