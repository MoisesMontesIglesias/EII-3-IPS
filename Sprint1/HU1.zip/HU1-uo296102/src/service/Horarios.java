package service;

import java.util.List;

import modelApp.Actividad;
import modelApp.ListaActividades;

public class Horarios {
	
	private ListaActividades listaActividades = new ListaActividades();
	
	public void CargarLista() {
		listaActividades = new ListaActividades();
	}
	
	public List<Actividad> getListaActividades(){
		return listaActividades.getLista();
	}

	public List<Actividad> cargarActividades() {
		return ordenarLista(listaActividades.getLista());
	}

	public List<Actividad> ordenarLista(List<Actividad> lista) {
		return listaActividades.ordenarLista(lista);
		
	}

	public void eliminarActividad(int posicion) {
		listaActividades.eliminarActividad(posicion);
	}
	
	public void recargarLista() {
		listaActividades.reiniciarLista();
	}
}
