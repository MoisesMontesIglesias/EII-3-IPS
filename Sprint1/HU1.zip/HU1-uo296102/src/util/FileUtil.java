package util;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import modelApp.Actividad;

public abstract class FileUtil {
	
	public static final String DRIVER="org.sqlite.JDBC";
	public static final String URL="jdbc:sqlite:DemoDB.db";

	//private static final Logger log=LoggerFactory.getLogger(FileUtil.class);

	public static void loadFileActividad(String nombreFicheroEntrada, List<Actividad> listaActividades) {

		String linea;
		String[] datosLista = null;

		try {
			BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
			while (fichero.ready()) {
				linea = fichero.readLine();
				datosLista = linea.split(";");
				listaActividades.add(new Actividad(datosLista[0], datosLista[1], datosLista[2], datosLista[3], datosLista[4]));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
	
	public static void saveToFileActividades(Actividad act) {
		try {
			BufferedWriter fichero = new BufferedWriter(new FileWriter("files/actividadesProgramadas.txt", true));
			fichero.write(act.getDisciplina() + ";" + act.getFechaFinal() + ";" + act.getFechaInicio() + ";" + act.getFechaIniMatricula() + ";" + act.getFechaFinMatricula());
			fichero.newLine();
			fichero.close();
        }
		catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha podido guardar");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida");
		}
	}
	
	public static void eliminarActividad(List<Actividad> listaActividades) {
		try {
			BufferedWriter fichero = new BufferedWriter(new FileWriter("files/actividadesProgramadas.txt"));
			for (int i = 0; i < listaActividades.size(); i++) {
				fichero.write(listaActividades.get(i).toString());
				fichero.newLine();
			}
			fichero.close();
        }
		catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha podido guardar");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida");
		}
	}
	
	public static void getActividad(List<Actividad> listaActividades) {
		String linea;
		String[] datosLista = null;
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/actividadesProgramadas.txt"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				datosLista = linea.split(";");
				listaActividades.add(new Actividad(datosLista[0], datosLista[1], datosLista[2], datosLista[3], datosLista[4]));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
	
	/**
	 * Creacion de tabla para los ejemplos a partir del segundo
	 */
	private void createTable() {
		//el try with resources nos va a asegurar que los objetos cn y stmt siempre se cierran haya o no excepcion
		try (Connection cn=DriverManager.getConnection(URL)) { //NOSONAR
			try (Statement stmt = cn.createStatement()) {
				stmt.executeUpdate("drop table if exists Test");
				stmt.executeUpdate("create table Test(id int not null, id2 int, text varchar(32))");
				stmt.executeUpdate("insert into Test(id,id2,text) values(1,null,'abc')");
				stmt.executeUpdate("insert into Test(id,id2,text) values(2,9999,'xyz')");
			}
		} catch (SQLException e) {
			//Ojo, no dejar pasar las excepciones (no limitarse a dejar el codigo autoegenerado por Eclipse haciendo solo printStackTrace)
			//throw new UnexpectedException(e); //Es mas habitual usar excepciones propias de la aplicacion
		}
	}
	
	public void aaa() {
		createTable();
		//En vez de crear un Statement y pasar el sql en executeQuery,
		//se crea un PreparedStatement con el sql, luego se le ponen los parametros y finalmente se ejecuta
		try (Connection cn=DriverManager.getConnection(URL); //NOSONAR
			PreparedStatement pstmt=cn.prepareStatement("select id,id2,text from Test where id>=?")) {
			pstmt.setInt(1, 2); // pone valor 2 en el primer (y unico) parametro
			try (ResultSet rs=pstmt.executeQuery()) {
				while (rs.next()) {
					//log.info("demo3Parameters - rs(1): {} rs(2): {} rs(3): {}", rs.getInt(1), rs.getInt(2), rs.getString(3));
				}
			}
		} catch (SQLException e) {
			//throw new UnexpectedException(e);
		}
		//de forma similar se pueden ejecutar acciones de actualizacion sobre el PreparedStatement
	}
}
