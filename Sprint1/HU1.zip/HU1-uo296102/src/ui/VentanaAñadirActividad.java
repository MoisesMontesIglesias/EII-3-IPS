package ui;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelApp.Actividad;
import service.Horarios;
import util.FileUtil;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.YearMonth;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.DefaultComboBoxModel;

public class VentanaA�adirActividad extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnPrincipal;
	private JLabel lblDisciplina;
	private JLabel lblFechaInicio;
	private JLabel lblFechaFinal;
	private JTextField txtDisciplina;
	private JButton btnAnadir;
	private JButton btnCancelar;
	private JLabel lblTitulo;
	private JPanel pnCalendario;
	private JComboBox<String> cbxMes;
    private JComboBox<Integer> cbxAnio;
    private Horarios horarios;
    private JPanel pnSuperior;
	private JPanel pnFechas;
	private BotonDias pBD = new BotonDias();
	private JTextField txtFechaInicio;
	private JTextField txtFechaFinal;
	private JLabel lblErrorFechas;
	private JLabel lblErrorNombre;
	private VentanaPrincipal vP;
	private JLabel lblFechaMatInicio;
	private JLabel lblFechaMatFin;
	private JTextField txtIniMatriculacion;
	private JTextField txtFinMatriculacion;

	/**
	 * Create the frame.
	 * @param horarios 
	 */
	public VentanaA�adirActividad(VentanaPrincipal vP, Horarios horarios) {
		this.vP = vP;
		this.horarios = horarios;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 756, 596);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(Color.WHITE);
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getLblDisciplina());
		pnPrincipal.add(getLblFechaInicio());
		pnPrincipal.add(getLblFechaFinal());
		pnPrincipal.add(getTxtDisciplina());
		pnPrincipal.add(getBtnAnadir());
		pnPrincipal.add(getBtnCancelar());
		pnPrincipal.add(getLblTitulo());
		pnPrincipal.add(getPnCalendario());
		pnPrincipal.add(getTxtFechaInicio());
		pnPrincipal.add(getTxtFechaFinal());
		pnPrincipal.add(getLblErrorFechas());
		pnPrincipal.add(getLblErrorNombre());
		pnPrincipal.add(getLblFechaMatInicio());
		pnPrincipal.add(getLblFechaMatFin());
		pnPrincipal.add(getTxtIniMatriculacion());
		pnPrincipal.add(getTxtFinMatriculacion());
		
	}
	
	public Horarios getHorarios() {
		return horarios;
	}

	private JLabel getLblDisciplina() {
		if (lblDisciplina == null) {
			lblDisciplina = new JLabel("Nombre disciplina:");
			lblDisciplina.setFont(new Font("Arial", Font.PLAIN, 18));
			lblDisciplina.setBounds(10, 64, 335, 38);
		}
		return lblDisciplina;
	}
	private JLabel getLblFechaInicio() {
		if (lblFechaInicio == null) {
			lblFechaInicio = new JLabel("Fecha inicia\u00F1 de actividad:");
			lblFechaInicio.setFont(new Font("Arial", Font.PLAIN, 18));
			lblFechaInicio.setBounds(10, 113, 335, 38);
		}
		return lblFechaInicio;
	}
	private JLabel getLblFechaFinal() {
		if (lblFechaFinal == null) {
			lblFechaFinal = new JLabel("Fecha final de actividad:");
			lblFechaFinal.setFont(new Font("Arial", Font.PLAIN, 18));
			lblFechaFinal.setBounds(10, 162, 335, 38);
		}
		return lblFechaFinal;
	}
	private JTextField getTxtDisciplina() {
		if (txtDisciplina == null) {
			txtDisciplina = new JTextField();
			txtDisciplina.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtDisciplina.setHorizontalAlignment(SwingConstants.RIGHT);
			txtDisciplina.setBounds(355, 64, 372, 38);
			txtDisciplina.setColumns(10);
		}
		return txtDisciplina;
	}
	private JButton getBtnAnadir() {
		if (btnAnadir == null) {
			btnAnadir = new JButton("A\u00D1ADIR");
			btnAnadir.setBackground(Color.GREEN);
			btnAnadir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comprobarActividad();
				}
			});
			btnAnadir.setFont(new Font("Arial", Font.PLAIN, 18));
			btnAnadir.setBounds(590, 459, 137, 38);
		}
		return btnAnadir;
	}
	private void comprobarActividad() {
		comprobarNombre();
		comprobarFechas();
		comprobarErrores();
	}

	private void comprobarErrores() {
		if(getLblErrorNombre().getText().equals(new String()) && getLblErrorFechas().getText().equals(new String())) {
			String disciplina = getTxtDisciplina().getText();
			String fecIni = getTxtFechaInicio().getText();
			String fecFin = getTxtFechaFinal().getText();
			String fecIniMat = getTxtIniMatriculacion().getText();
			String fecFinMat = getTxtFinMatriculacion().getText();
			Actividad act = new Actividad(disciplina, fecIni, fecFin, fecIniMat, fecFinMat);
			FileUtil.saveToFileActividades(act);
			JOptionPane.showMessageDialog(null, "�Actividad a�adida con �xito!");
			dispose();
			horarios.recargarLista();
			vP.getLblActividadesProgramadas().setText(vP.getActividades());
		}
	}

	private void comprobarFechas() {
		String[] fecIni = getTxtFechaInicio().getText().split("/");
		String[] fecFin = getTxtFechaFinal().getText().split("/");
		String txtIni = getTxtFechaInicio().getText();
		String txtFin = getTxtFechaFinal().getText();
		String[] fecIniMat = getTxtIniMatriculacion().getText().split("/");
		String[] fecFinMat = getTxtFinMatriculacion().getText().split("/");
		String txtIniMat = getTxtIniMatriculacion().getText();
		String txtFinMat = getTxtFinMatriculacion().getText();
		int errores = 0;
		if(txtIni.isEmpty() || txtFin.isEmpty() || txtIniMat.isEmpty() || txtFinMat.isEmpty()) {
			errores += 1;
		} else {
			if(Integer.parseInt(fecIni[2]) <= Integer.parseInt(fecFin[2])) {
				if(Integer.parseInt(fecIni[1]) <= Integer.parseInt(fecFin[1])) {
					if(Integer.parseInt(fecIni[0]) <= Integer.parseInt(fecFin[0])) {
					} else {
						errores += 1;
					}
				} else {
					errores+=1;
				}
			} else {
				errores += 1;
			}
			if(Integer.parseInt(fecIniMat[2]) <= Integer.parseInt(fecFinMat[2])) {
				if(Integer.parseInt(fecIniMat[1]) <= Integer.parseInt(fecFinMat[1])) {
					if(Integer.parseInt(fecIniMat[0]) <= Integer.parseInt(fecFinMat[0])) {
					} else {
						errores += 1;
					}
				} else {
					errores+=1;
				}
			} else {
				errores += 1;
			}
		}
		if(errores > 0) {
			getLblErrorFechas().setText("Error en las fechas");
		} else {
			getLblErrorFechas().setText(new String());
		}
	}

	private void comprobarNombre() {
		String txt = getTxtDisciplina().getText();
		if(txt.isEmpty() || txt.isBlank() || txt.equals(null)) {
			getLblErrorNombre().setText("Error en el nombre");
		} else {
			getLblErrorNombre().setText(new String());
		}
	}

	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("CANCELAR");
			btnCancelar.setBackground(Color.RED);
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCancelar.setFont(new Font("Arial", Font.PLAIN, 18));
			btnCancelar.setBounds(590, 508, 137, 38);
		}
		return btnCancelar;
	}
	private JLabel getLblTitulo() {
		if (lblTitulo == null) {
			lblTitulo = new JLabel("Nueva Disciplina A Impartir");
			lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
			lblTitulo.setFont(new Font("Arial", Font.PLAIN, 18));
			lblTitulo.setBounds(171, 11, 409, 38);
		}
		return lblTitulo;
	}
	private JPanel getPnCalendario() {
		if (pnCalendario == null) {
			pnCalendario = new JPanel();
			pnCalendario.setBounds(10, 303, 570, 243);
			pnCalendario.setLayout(new BorderLayout());
			pnCalendario.add(getPnSuperior(), BorderLayout.NORTH);
			pnCalendario.add(getPnFechas(), BorderLayout.CENTER);
		}
		return pnCalendario;
	}
	private JPanel getPnSuperior() {
		if (pnSuperior == null) {
			pnSuperior = new JPanel();
	        LocalDate fechaActual = LocalDate.now();
	        getCbxMes().setSelectedIndex(fechaActual.getMonthValue() - 1);
	        getCbxAnio().setSelectedItem(fechaActual.getYear());
	
	        getCbxMes().addActionListener(e -> actualizarCalendario());
	        getCbxAnio().addActionListener(e -> actualizarCalendario());
	        pnSuperior.add(getCbxMes());
	        pnSuperior.add(getCbxAnio());
		}
		return pnSuperior;
	}
	
	private JComboBox<String> getCbxMes(){
		if(cbxMes == null) {
			cbxMes = new JComboBox<>();
			cbxMes.setModel(new DefaultComboBoxModel<String>(new String[] {"Enero", 
					"Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", 
					"Septiembre", "Octubre", "Noviembre", "Diciembre"}));
		}
		return cbxMes;
	}
	
	private JComboBox<Integer> getCbxAnio(){
		if(cbxAnio == null) {
			cbxAnio = new JComboBox<>();
	        for (int i = 2024; i <= 2124; i++) {
	            cbxAnio.addItem(i);
	        }
		}
		return cbxAnio;
	}

	private JPanel getPnFechas() {
		if (pnFechas == null) {
			pnFechas = new JPanel();
			pnFechas.setLayout(new GridLayout(7, 7));
			String[] diasSemana = { "Dom", "Lun", "Mar", "Mi�", "Jue", "Vie", "S�b" };
	        for (String dia : diasSemana) {
	        	pnFechas.add(new JLabel(dia, SwingConstants.CENTER));
	        }
	        pnCalendario.add(getPnSuperior(), BorderLayout.NORTH);
	        pnCalendario.add(getPnFechas(), BorderLayout.CENTER);
	        
	        actualizarCalendario();
	        actualizarCalendario();
		}
		return pnFechas;
	}
	 private void actualizarCalendario() {
		 getPnFechas().removeAll();
	    for (String dia : new String[]{"Lun", "Mar", "Mi�", "Jue", "Vie", "S�b","Dom" }) {
	    	getPnFechas().add(new JLabel(dia, SwingConstants.CENTER));
	    }
	    int mesSeleccionado = getCbxMes().getSelectedIndex() + 1;
	    int a�oSeleccionado = (int) getCbxAnio().getSelectedItem();
	    YearMonth mesA�o = YearMonth.of(a�oSeleccionado, mesSeleccionado);
	    LocalDate primerDiaDelMes = mesA�o.atDay(1);
	    int diasEnMes = mesA�o.lengthOfMonth();
	    int diaSemanaInicio = primerDiaDelMes.getDayOfWeek().getValue(); 
	    diaSemanaInicio = diaSemanaInicio - 1;
	    for (int i = 0; i < diaSemanaInicio; i++) {
	    	getPnFechas().add(new JLabel(""));
	    }
	    for (int dia = 1; dia <= diasEnMes; dia++) {
	        JButton botonDia = new JButton(String.valueOf(dia));
	        botonDia.addActionListener(pBD);
	        getPnFechas().add(botonDia);
	    }
	    for (int i = getPnFechas().getComponentCount(); i < 49; i++) {
	    	getPnFechas().add(new JLabel(""));
	    }
	    getPnFechas().revalidate();
	    getPnFechas().repaint();
	}
	 
	 class BotonDias implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				JButton botonPulsado = (JButton) e.getSource();
				String cadena = "";
				cadena += botonPulsado.getText() + "/";
				cadena += getCbxMes().getSelectedIndex() + "/";
				cadena += getCbxAnio().getSelectedItem();
				String[] opciones = {"Fecha inicio", 
						"Fecha fin", "Fecha inicio matricula", "Fecha fin matricula"};
				int eleccion = JOptionPane.showOptionDialog(null, "�Para que fecha has elegido esto?", 
						"Nueva actividad", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
				if(eleccion == 0) {
					getTxtFechaInicio().setText(cadena);
				} else if(eleccion == 1) {
					getTxtFechaFinal().setText(cadena);
				} else if(eleccion == 2) {
					getTxtIniMatriculacion().setText(cadena);
				}else {
					getTxtFinMatriculacion().setText(cadena);
				}
			}
		}
	 
	private JTextField getTxtFechaInicio() {
		if (txtFechaInicio == null) {
			txtFechaInicio = new JTextField();
			txtFechaInicio.setHorizontalAlignment(SwingConstants.RIGHT);
			txtFechaInicio.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtFechaInicio.setBounds(355, 113, 372, 38);
			txtFechaInicio.setColumns(10);
		}
		return txtFechaInicio;
	}

	private JTextField getTxtFechaFinal() {
		if (txtFechaFinal == null) {
			txtFechaFinal = new JTextField();
			txtFechaFinal.setHorizontalAlignment(SwingConstants.RIGHT);
			txtFechaFinal.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtFechaFinal.setBounds(355, 162, 372, 38);
			txtFechaFinal.setColumns(10);
		}
		return txtFechaFinal;
	}
	private JLabel getLblErrorFechas() {
		if (lblErrorFechas == null) {
			lblErrorFechas = new JLabel("");
			lblErrorFechas.setForeground(Color.RED);
			lblErrorFechas.setFont(new Font("Arial", Font.BOLD, 14));
			lblErrorFechas.setBounds(590, 303, 137, 27);
		}
		return lblErrorFechas;
	}
	private JLabel getLblErrorNombre() {
		if (lblErrorNombre == null) {
			lblErrorNombre = new JLabel("");
			lblErrorNombre.setForeground(Color.RED);
			lblErrorNombre.setFont(new Font("Arial", Font.BOLD, 14));
			lblErrorNombre.setBounds(590, 341, 137, 27);
		}
		return lblErrorNombre;
	}
	private JLabel getLblFechaMatInicio() {
		if (lblFechaMatInicio == null) {
			lblFechaMatInicio = new JLabel("Fecha de inicio de matriculaci\u00F3n:");
			lblFechaMatInicio.setFont(new Font("Arial", Font.PLAIN, 18));
			lblFechaMatInicio.setBounds(10, 211, 335, 38);
		}
		return lblFechaMatInicio;
	}
	private JLabel getLblFechaMatFin() {
		if (lblFechaMatFin == null) {
			lblFechaMatFin = new JLabel("Fecha final de matriculaci\u00F3n:");
			lblFechaMatFin.setFont(new Font("Arial", Font.PLAIN, 18));
			lblFechaMatFin.setBounds(10, 254, 335, 38);
		}
		return lblFechaMatFin;
	}
	private JTextField getTxtIniMatriculacion() {
		if (txtIniMatriculacion == null) {
			txtIniMatriculacion = new JTextField();
			txtIniMatriculacion.setHorizontalAlignment(SwingConstants.RIGHT);
			txtIniMatriculacion.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtIniMatriculacion.setBounds(355, 211, 372, 38);
			txtIniMatriculacion.setColumns(10);
		}
		return txtIniMatriculacion;
	}
	private JTextField getTxtFinMatriculacion() {
		if (txtFinMatriculacion == null) {
			txtFinMatriculacion = new JTextField();
			txtFinMatriculacion.setHorizontalAlignment(SwingConstants.RIGHT);
			txtFinMatriculacion.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtFinMatriculacion.setBounds(355, 254, 372, 38);
			txtFinMatriculacion.setColumns(10);
		}
		return txtFinMatriculacion;
	}
}
