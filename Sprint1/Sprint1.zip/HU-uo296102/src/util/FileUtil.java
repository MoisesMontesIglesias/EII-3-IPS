package util;

import java.io.*;
import java.util.*;

import modelApp.Actividad;

public abstract class FileUtil {

	public static void loadFileActividad(String nombreFicheroEntrada, List<Actividad> listaActividades) {

		String linea;
		String[] datosLista = null;

		try {
			BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
			while (fichero.ready()) {
				linea = fichero.readLine();
				datosLista = linea.split(";");
				listaActividades.add(new Actividad(datosLista[0], datosLista[1], datosLista[2], datosLista[3], datosLista[4]));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
	
	public static void saveToFileActividades(Actividad act) {
		try {
			BufferedWriter fichero = new BufferedWriter(new FileWriter("files/actividadesProgramadas.txt", true));
			fichero.write(act.getDisciplina() + ";" + act.getFechaFinal() + ";" + act.getFechaInicio());
			fichero.newLine();
			fichero.close();
        }
		catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha podido guardar");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida");
		}
	}
	
	public static void eliminarActividad(String actividad) {
		try {
			BufferedWriter fichero = new BufferedWriter(new FileWriter("files/descuentos.dat"));
			fichero.write(actividad.toString());
			fichero.close();
        }
		catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha podido guardar");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida");
		}
	}
	
	public static void getActividad(List<Actividad> listaActividades) {
		String linea;
		String[] datosLista = null;
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/actividadesProgramadas.txt"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				datosLista = linea.split(";");
				listaActividades.add(new Actividad(datosLista[0], datosLista[1], datosLista[2], datosLista[3], datosLista[4]));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
}
