package ui;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelApp.Actividad;
import service.Horarios;
import util.FileUtil;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Date;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.DefaultComboBoxModel;

public class VentanaA�adirActividad extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnPrincipal;
	private JLabel lblDisciplina;
	private JLabel lblFechaInicio;
	private JLabel lblFechaFinal;
	private JTextField txtDisciplina;
	private JButton btnAnadir;
	private JButton btnCancelar;
	private JLabel lblTitulo;
	private JPanel pnCalendario;
	private JComboBox<String> cbxMes;
    private JComboBox<Integer> cbxAnio;
    private Horarios horarios;
    private JPanel pnSuperior;
	private JPanel pnFechas;
	private BotonDias pBD = new BotonDias();
	private JTextField txtFechaInicio;
	private JTextField txtFechaFinal;
	private JLabel lblErrorFechas;
	private JLabel lblErrorNombre;
	private VentanaPrincipal vP;

	/**
	 * Create the frame.
	 * @param horarios 
	 */
	public VentanaA�adirActividad(VentanaPrincipal vP, Horarios horarios) {
		this.vP = vP;
		this.horarios = horarios;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 753, 501);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(Color.WHITE);
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getLblDisciplina());
		pnPrincipal.add(getLblFechaInicio());
		pnPrincipal.add(getLblFechaFinal());
		pnPrincipal.add(getTxtDisciplina());
		pnPrincipal.add(getBtnAnadir());
		pnPrincipal.add(getBtnCancelar());
		pnPrincipal.add(getLblTitulo());
		pnPrincipal.add(getPnCalendario());
		pnPrincipal.add(getTxtFechaInicio());
		pnPrincipal.add(getTxtFechaFinal());
		pnPrincipal.add(getLblErrorFechas());
		pnPrincipal.add(getLblErrorNombre());
		
	}
	
	public Horarios getHorarios() {
		return horarios;
	}

	private JLabel getLblDisciplina() {
		if (lblDisciplina == null) {
			lblDisciplina = new JLabel("Nombre disciplina:");
			lblDisciplina.setFont(new Font("Arial", Font.PLAIN, 18));
			lblDisciplina.setBounds(10, 64, 195, 38);
		}
		return lblDisciplina;
	}
	private JLabel getLblFechaInicio() {
		if (lblFechaInicio == null) {
			lblFechaInicio = new JLabel("Fecha de inicio:");
			lblFechaInicio.setFont(new Font("Arial", Font.PLAIN, 18));
			lblFechaInicio.setBounds(10, 113, 195, 38);
		}
		return lblFechaInicio;
	}
	private JLabel getLblFechaFinal() {
		if (lblFechaFinal == null) {
			lblFechaFinal = new JLabel("Fecha de finalizaci\u00F3n:");
			lblFechaFinal.setFont(new Font("Arial", Font.PLAIN, 18));
			lblFechaFinal.setBounds(10, 162, 195, 38);
		}
		return lblFechaFinal;
	}
	private JTextField getTxtDisciplina() {
		if (txtDisciplina == null) {
			txtDisciplina = new JTextField();
			txtDisciplina.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtDisciplina.setHorizontalAlignment(SwingConstants.RIGHT);
			txtDisciplina.setBounds(215, 64, 512, 38);
			txtDisciplina.setColumns(10);
		}
		return txtDisciplina;
	}
	private JButton getBtnAnadir() {
		if (btnAnadir == null) {
			btnAnadir = new JButton("A\u00D1ADIR");
			btnAnadir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comprobarActividad();
				}
			});
			btnAnadir.setFont(new Font("Arial", Font.PLAIN, 18));
			btnAnadir.setBounds(590, 364, 137, 38);
		}
		return btnAnadir;
	}
	private void comprobarActividad() {
		comprobarNombre();
		comprobarFecha();
		comprobarErrores();
	}

	private void comprobarErrores() {
		if(getLblErrorNombre().getText().equals(new String()) && getLblErrorFechas().getText().equals(new String())) {
			String disciplina = getTxtDisciplina().getText();
			String fecIni = getTxtFechaInicio().getText();
			String fecFin = getTxtFechaFinal().getText();
			String fecIniMat = getTxtFechaFinal().getText();
			String fecFinMat = 
			Actividad act = new Actividad(disciplina, fecIni, fecFin);
			FileUtil.saveToFileActividades(act);
			JOptionPane.showMessageDialog(null, "�Actividad a�adida con �xito!");
			dispose();
			horarios.recargarLista();
			vP.getLblActividadesProgramadas().setText(vP.getActividades());
		}
	}

	private void comprobarFecha() {
		String[] fecIni = getTxtFechaInicio().getText().split("/");
		String[] fecFin = getTxtFechaFinal().getText().split("/");
		String txtIni = getTxtFechaInicio().getText();
		String txtFin = getTxtFechaFinal().getText();
		int errores = 0;
		if(txtIni.isEmpty() || txtIni.isBlank() || txtIni.equals(null) || txtFin.isBlank() || txtFin.isEmpty() || txtFin.equals(null)) {
			errores += 1;
		} else {
			if(Integer.parseInt(fecIni[2]) <= Integer.parseInt(fecFin[2])) {
				if(Integer.parseInt(fecIni[1]) <= Integer.parseInt(fecFin[1])) {
					if(Integer.parseInt(fecIni[0]) < Integer.parseInt(fecFin[0])) {
					} else {
						errores += 1;
					}
				} else {
					errores+=1;
				}
			} else {
				errores += 1;
			}
		}
		if(errores > 0) {
			getLblErrorFechas().setText("Error en las fechas");
		} else {
			getLblErrorFechas().setText(new String());
		}
	}

	private void comprobarNombre() {
		String txt = getTxtDisciplina().getText();
		if(txt.isEmpty() || txt.isBlank() || txt.equals(null)) {
			getLblErrorNombre().setText("Error en el nombre");
		} else {
			getLblErrorNombre().setText(new String());
		}
	}

	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("CANCELAR");
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCancelar.setFont(new Font("Arial", Font.PLAIN, 18));
			btnCancelar.setBounds(590, 413, 137, 38);
		}
		return btnCancelar;
	}
	private JLabel getLblTitulo() {
		if (lblTitulo == null) {
			lblTitulo = new JLabel("Nueva Disciplina A Impartir");
			lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
			lblTitulo.setFont(new Font("Arial", Font.PLAIN, 18));
			lblTitulo.setBounds(171, 11, 409, 38);
		}
		return lblTitulo;
	}
	private JPanel getPnCalendario() {
		if (pnCalendario == null) {
			pnCalendario = new JPanel();
			pnCalendario.setBounds(10, 216, 570, 235);
			pnCalendario.setLayout(new BorderLayout());
			pnCalendario.add(getPnSuperior(), BorderLayout.NORTH);
			pnCalendario.add(getPnFechas(), BorderLayout.CENTER);
		}
		return pnCalendario;
	}
	private JPanel getPnSuperior() {
		if (pnSuperior == null) {
			pnSuperior = new JPanel();
	        LocalDate fechaActual = LocalDate.now();
	        getCbxMes().setSelectedIndex(fechaActual.getMonthValue() - 1);
	        getCbxAnio().setSelectedItem(fechaActual.getYear());
	
	        getCbxMes().addActionListener(e -> actualizarCalendario());
	        getCbxAnio().addActionListener(e -> actualizarCalendario());
	        pnSuperior.add(getCbxMes());
	        pnSuperior.add(getCbxAnio());
		}
		return pnSuperior;
	}
	
	private JComboBox<String> getCbxMes(){
		if(cbxMes == null) {
			cbxMes = new JComboBox<>();
			cbxMes.setModel(new DefaultComboBoxModel<String>(new String[] {"Enero", 
					"Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", 
					"Septiembre", "Octubre", "Noviembre", "Diciembre"}));
		}
		return cbxMes;
	}
	
	private JComboBox<Integer> getCbxAnio(){
		if(cbxAnio == null) {
			cbxAnio = new JComboBox<>();
	        for (int i = 2024; i <= 2124; i++) {
	            cbxAnio.addItem(i);
	        }
		}
		return cbxAnio;
	}

	private JPanel getPnFechas() {
		if (pnFechas == null) {
			pnFechas = new JPanel();
			pnFechas.setLayout(new GridLayout(7, 7));
			String[] diasSemana = { "Dom", "Lun", "Mar", "Mi�", "Jue", "Vie", "S�b" };
	        for (String dia : diasSemana) {
	        	pnFechas.add(new JLabel(dia, SwingConstants.CENTER));
	        }
	        pnCalendario.add(getPnSuperior(), BorderLayout.NORTH);
	        pnCalendario.add(getPnFechas(), BorderLayout.CENTER);
	        
	        actualizarCalendario();
	        actualizarCalendario();
		}
		return pnFechas;
	}
	 private void actualizarCalendario() {
		 getPnFechas().removeAll();
	    for (String dia : new String[]{"Lun", "Mar", "Mi�", "Jue", "Vie", "S�b","Dom" }) {
	    	getPnFechas().add(new JLabel(dia, SwingConstants.CENTER));
	    }
	    int mesSeleccionado = getCbxMes().getSelectedIndex() + 1;
	    int a�oSeleccionado = (int) getCbxAnio().getSelectedItem();
	    YearMonth mesA�o = YearMonth.of(a�oSeleccionado, mesSeleccionado);
	    LocalDate primerDiaDelMes = mesA�o.atDay(1);
	    int diasEnMes = mesA�o.lengthOfMonth();
	    int diaSemanaInicio = primerDiaDelMes.getDayOfWeek().getValue(); 
	    diaSemanaInicio = diaSemanaInicio - 1;
	    for (int i = 0; i < diaSemanaInicio; i++) {
	    	getPnFechas().add(new JLabel(""));
	    }
	    for (int dia = 1; dia <= diasEnMes; dia++) {
	        JButton botonDia = new JButton(String.valueOf(dia));
	        botonDia.addActionListener(pBD);
	        getPnFechas().add(botonDia);
	    }
	    for (int i = getPnFechas().getComponentCount(); i < 49; i++) {
	    	getPnFechas().add(new JLabel(""));
	    }
	    getPnFechas().revalidate();
	    getPnFechas().repaint();
	}
	 
	 class BotonDias implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				JButton botonPulsado = (JButton) e.getSource();
				String cadena = "";
				cadena += botonPulsado.getText() + "/";
				cadena += getCbxMes().getSelectedIndex() + "/";
				cadena += getCbxAnio().getSelectedItem();
				if(botonPulsado.isSelected()) {
					botonPulsado.setSelected(false);
					if(cadena.equals(getTxtFechaInicio().getText())) {
						getTxtFechaInicio().setText(new String());
					}else {
						getTxtFechaFinal().setText(new String());
					}
				} else {
					botonPulsado.setSelected(true);
					if(getTxtFechaInicio().getText().isEmpty()) {
						getTxtFechaInicio().setText(cadena);
					} else if(getTxtFechaFinal().getText().isEmpty()){
						getTxtFechaFinal().setText(cadena);
					}else {
						cambiarFecha(cadena);
						
					}
				}
			}
		}
	 
	public void cambiarFecha(String cadena) {
		if(!getTxtFechaInicio().getText().isEmpty() && !getTxtFechaFinal().getText().isEmpty()) {
			int[] fechaCadInt = new int[cadena.split("/").length];
			int[] fechaIniInt = new int[getTxtFechaInicio().getText().split("/").length];
			String[] fechaCad =cadena.split("/");
			String[] fechaIni = getTxtFechaInicio().getText().split("/");
			for (int i = 0; i < fechaCad.length; i++) {
				fechaCadInt[i] = Integer.parseInt(fechaCad[i]);
				fechaIniInt[i] = Integer.parseInt(fechaIni[i]);
			}
			@SuppressWarnings("deprecation")
			Date fecha = new Date(fechaCadInt[2], fechaCadInt[1], fechaCadInt[0]);
			@SuppressWarnings("deprecation")
			Date fecha2 = new Date(fechaIniInt[2], fechaIniInt[1], fechaIniInt[0]);
			if(fecha.compareTo(fecha2) < 0) {
				getTxtFechaInicio().setText(cadena);
			} else {
				getTxtFechaFinal().setText(cadena);
			}
		}
	}
	 
	private JTextField getTxtFechaInicio() {
		if (txtFechaInicio == null) {
			txtFechaInicio = new JTextField();
			txtFechaInicio.setHorizontalAlignment(SwingConstants.RIGHT);
			txtFechaInicio.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtFechaInicio.setBounds(215, 113, 512, 38);
			txtFechaInicio.setColumns(10);
		}
		return txtFechaInicio;
	}

	private JTextField getTxtFechaFinal() {
		if (txtFechaFinal == null) {
			txtFechaFinal = new JTextField();
			txtFechaFinal.setHorizontalAlignment(SwingConstants.RIGHT);
			txtFechaFinal.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 22));
			txtFechaFinal.setBounds(215, 162, 512, 38);
			txtFechaFinal.setColumns(10);
		}
		return txtFechaFinal;
	}
	private JLabel getLblErrorFechas() {
		if (lblErrorFechas == null) {
			lblErrorFechas = new JLabel("");
			lblErrorFechas.setFont(new Font("Arial", Font.BOLD, 14));
			lblErrorFechas.setBounds(590, 216, 137, 27);
		}
		return lblErrorFechas;
	}
	private JLabel getLblErrorNombre() {
		if (lblErrorNombre == null) {
			lblErrorNombre = new JLabel("");
			lblErrorNombre.setFont(new Font("Arial", Font.BOLD, 14));
			lblErrorNombre.setBounds(590, 254, 137, 27);
		}
		return lblErrorNombre;
	}
}
