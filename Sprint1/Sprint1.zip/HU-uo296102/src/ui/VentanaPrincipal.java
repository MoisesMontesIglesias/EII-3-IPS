package ui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import modelApp.Actividad;
import service.Horarios;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.SwingConstants;
import javax.swing.JButton;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnPrincipal;
	private JScrollPane scpnActividades;
	private JLabel lblActividadesTxt;
	private JTextArea lblActividadesProgramadas;
	private Horarios horarios;
	private JButton btnNuevaActividad;
	private JButton btnEliminarActividad;

	/**
	 * Create the frame.
	 * @param horarios 
	 */
	public VentanaPrincipal(Horarios horarios) {
		this.horarios = horarios;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 855, 541);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(Color.WHITE);
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getBtnNuevaActividad());
		pnPrincipal.add(getBtnEliminarActividad());
		pnPrincipal.add(getScpnActividades());
	}
	private JScrollPane getScpnActividades() {
		if (scpnActividades == null) {
			scpnActividades = new JScrollPane();
			scpnActividades.setBounds(10, 11, 819, 432);
			scpnActividades.setBackground(Color.WHITE);
			scpnActividades.setColumnHeaderView(getLblActividadesTxt());
			scpnActividades.setViewportView(getLblActividadesProgramadas());
		}
		return scpnActividades;
	}
	private JLabel getLblActividadesTxt() {
		if (lblActividadesTxt == null) {
			lblActividadesTxt = new JLabel("Actividades programadas para el trimestre");
			lblActividadesTxt.setHorizontalAlignment(SwingConstants.CENTER);
			lblActividadesTxt.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 24));
			lblActividadesTxt.setBorder(new LineBorder(Color.BLACK));
		}
		return lblActividadesTxt;
	}
	protected JTextArea getLblActividadesProgramadas() {
		if (lblActividadesProgramadas == null) {
			lblActividadesProgramadas = new JTextArea();
			lblActividadesProgramadas.setFont(new Font("Arial", Font.BOLD, 16));
			lblActividadesProgramadas.setEditable(false);
			lblActividadesProgramadas.setText(getActividades());
			lblActividadesProgramadas.setBorder(new LineBorder(Color.BLACK));
		}
		return lblActividadesProgramadas;
	}

	public String getActividades() {
		List<Actividad> lista = horarios.cargarActividades();
		String cadena = "";
		for (int i = 0; i < lista.size(); i++) {
			cadena += lista.get(i).toString() + "\n";																																;
		}
		return cadena;
	}
	private JButton getBtnNuevaActividad() {
		if (btnNuevaActividad == null) {
			btnNuevaActividad = new JButton("Crear Nueva Actividad");
			btnNuevaActividad.setFont(new Font("Arial", Font.PLAIN, 18));
			btnNuevaActividad.setBounds(370, 454, 233, 37);
			btnNuevaActividad.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					a�adirActividad();
				}
			});
		}
		return btnNuevaActividad;
	}
	private void a�adirActividad() {
		VentanaA�adirActividad va = new VentanaA�adirActividad(this, horarios);
		va.setVisible(true);
	}
	private JButton getBtnEliminarActividad() {
		if (btnEliminarActividad == null) {
			btnEliminarActividad = new JButton("Eliminar Actividad");
			btnEliminarActividad.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					eliminarActividad();
				}
			});
			btnEliminarActividad.setFont(new Font("Arial", Font.PLAIN, 18));
			btnEliminarActividad.setBounds(613, 454, 216, 37);
		}
		return btnEliminarActividad;
	}
	private void eliminarActividad() {
		VentanaEliminarActividad vj = new VentanaEliminarActividad(horarios);
		vj.setVisible(true);
	}
}
