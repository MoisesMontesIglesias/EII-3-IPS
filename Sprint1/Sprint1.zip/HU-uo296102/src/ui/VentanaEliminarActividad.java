package ui;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelApp.Actividad;
import service.Horarios;
import util.FileUtil;

import java.awt.Color;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.GridLayout;

public class VentanaEliminarActividad extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel pnPrincipal;
	private Horarios horarios;
	private JScrollPane scpnActividades;
	private JLabel lblActividades;
	private JButton btnSalir;
	private BotonActividades pBA = new BotonActividades();
	private JPanel pnActividades;


	/**
	 * Create the frame.
	 * @param horarios 
	 */
	public VentanaEliminarActividad(Horarios horarios) {
		this.horarios = horarios;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 773, 447);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(Color.WHITE);
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getScpnActividades());
		pnPrincipal.add(getBtnSalir());
	}
	private JScrollPane getScpnActividades() {
		if (scpnActividades == null) {
			scpnActividades = new JScrollPane();
			scpnActividades.setBounds(10, 11, 737, 331);
			scpnActividades.setColumnHeaderView(getLblActividades());
			scpnActividades.setViewportView(getPnActividades());
			
		}
		return scpnActividades;
	}
	private void generarActividades() {
		List<Actividad> listaActividades = horarios.cargarActividades();
		if(listaActividades.size() == 0) {
			pnActividades.add(new JLabel("No hay ninguna actividad creada todav�a"));
		} else {
			for (int i = 0; i < listaActividades.size(); i++) {
		        JButton botonActividad = new JButton(listaActividades.get(i).toString());
		        botonActividad.addActionListener(pBA);
		        pnActividades.add(botonActividad);
		    }
		}
	}
	class BotonActividades implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			int respuesta = JOptionPane.showConfirmDialog(null, "�Est�s seguro de eliminar esta actividad programada?", "Eliminar actividad",  JOptionPane.INFORMATION_MESSAGE);
			if(respuesta == 0) {
				JButton botonPulsado = (JButton) e.getSource();
				eliminarActividad(botonPulsado);
			}
		}
	}
	private void eliminarActividad(JButton botonPulsado) {
		String[] actTxt = botonPulsado.getText().split(";");
		Actividad act = new Actividad(actTxt[0], actTxt[1], actTxt[2]);
		
		horarios.eliminarActividad(act);
		FileUtil.loadFileActividad(getName(), null);
		//reiniciarBotones();
		generarActividades();
	}
	private void reiniciarBotones() {
		for (int i = 0; i < getPnActividades().getComponentCount(); i++) {
			getPnActividades().remove(i);
		}
		generarActividades();
	}
	private JLabel getLblActividades() {
		if (lblActividades == null) {
			lblActividades = new JLabel("Actividades programadas");
			lblActividades.setHorizontalAlignment(SwingConstants.CENTER);
			lblActividades.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 24));
		}
		return lblActividades;
	}
	private JButton getBtnSalir() {
		if (btnSalir == null) {
			btnSalir = new JButton("Salir");
			btnSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnSalir.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 24));
			btnSalir.setBounds(568, 353, 179, 44);
		}
		return btnSalir;
	}
	private JPanel getPnActividades() {
		if (pnActividades == null) {
			pnActividades = new JPanel();
			pnActividades.setLayout(new GridLayout(horarios.cargarActividades().size(), 1, 1, 1));
			generarActividades();
		}
		return pnActividades;
	}
}
