package main;

import java.awt.EventQueue;

import service.Horarios;
import ui.VentanaPrincipal;

public class main {

	public static void main(String[] args) {
		Horarios horarios = new Horarios();
		EventQueue.invokeLater(new Runnable()
		{
			public void run() {
				try {
					//UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
					VentanaPrincipal frame = new VentanaPrincipal(horarios);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
