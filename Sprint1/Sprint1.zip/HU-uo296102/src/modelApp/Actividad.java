package modelApp;

public class Actividad {
	
	private String disciplina;
	private String fechaInicio;
	private String fechaFinal;
	private String fechaIniMatricula;
	private String fechaFinMatricula;
	
	public Actividad(String disciplina, String fechaInicio, String fechaFinal, String fechaIniMatricula, String fechaFinMatricula) {
		this.setDisciplina(disciplina);
		this.setFechaInicio(fechaInicio);
		this.setFechaFinal(fechaFinal);
		this.setFechaIniMatricula(fechaIniMatricula);
		this.setFechaFinMatricula(fechaFinMatricula);
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public String getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}

	public String getFechaIniMatricula() {
		return fechaIniMatricula;
	}

	public void setFechaIniMatricula(String fechaIniMatricula) {
		this.fechaIniMatricula = fechaIniMatricula;
	}

	public String getFechaFinMatricula() {
		return fechaFinMatricula;
	}

	public void setFechaFinMatricula(String fechaFinMatricula) {
		this.fechaFinMatricula = fechaFinMatricula;
	}
	
	@Override
	public String toString() {
		return getDisciplina() + ";" + getFechaInicio() + ";" + getFechaFinal() + ";" + getFechaIniMatricula() + ";" + getFechaFinMatricula();
	}
}
