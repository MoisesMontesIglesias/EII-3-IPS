package modelApp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import util.FileUtil;

public class ListaActividades {
	private static final String FICHERO_ACTIVIDADES = "files/actividadesProgramadas.txt";
	private List<Actividad> listaActividades = null;
	
	public ListaActividades() {
		listaActividades = new ArrayList<Actividad>();
		cargarActividades();
	}

	private void cargarActividades() {
		FileUtil.loadFileActividad(FICHERO_ACTIVIDADES, listaActividades);
	}
	
	public List<Actividad> getLista(){
		return listaActividades;
	}

	public List<Actividad> ordenarLista(List<Actividad> lista) {
		List<LocalDate> fechaOrdenar = new ArrayList<LocalDate>();
		for (int i = 0; i < lista.size(); i++) {
			String[] listaFecha = new String[2];
			listaFecha = lista.get(i).getFechaInicio().split("/");
			fechaOrdenar.add(LocalDate.of(Integer.parseInt(listaFecha[2]),Integer.parseInt(listaFecha[1]), Integer.parseInt(listaFecha[0])));
		}
		Collections.sort(fechaOrdenar);
		List<Actividad> nuevaLista = new ArrayList<Actividad>();
		for (int i = 0; i < lista.size(); i++) {
			String cadena = crearCadena(fechaOrdenar.get(i));
			for (int j = 0; j < lista.size(); j++) {
				if(cadena.equals(lista.get(j).getFechaInicio())) {
					nuevaLista.add(lista.get(j));
					j = lista.size();
				}
			}
		}
		return lista;
	}

	private String crearCadena(LocalDate fecha) {
		return String.valueOf(fecha.getDayOfMonth() + "/" + fecha.getMonthValue() + "/" + fecha.getYear());
	}

	public void eliminarActividad(Actividad actividad) {
		listaActividades.remove(actividad);
		FileUtil.eliminarActividad(actividad.toString());
	}

	public void reiniciarLista() {
		listaActividades = new ArrayList<Actividad>();
		cargarActividades();
		ordenarLista(listaActividades);
		
	}
}
